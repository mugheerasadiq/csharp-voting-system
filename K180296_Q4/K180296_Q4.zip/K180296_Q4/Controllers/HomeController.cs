﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Text;
using K180296_Q4.Models;

namespace K180296_Q4.Controllers
{
    public class HomeController : Controller
    {
        private static Dictionary<string, PositionModel> President = new Dictionary<string, PositionModel>();
        private static Dictionary<string, PositionModel> VicePresident = new Dictionary<string, PositionModel>();
        private static Dictionary<string, PositionModel> GeneralSecretary = new Dictionary<string, PositionModel>();

        private static void LoadCandidates()
        {
            try
            {
                string path = @"../../../../CandidateList.txt", line = "";
                StreamReader Reader = System.IO.File.OpenText(path);
                if (System.IO.File.Exists(path))
                {
                    while ((line = Reader.ReadLine()) != null)
                    {
                        string[] items = line.Split(',');
                        string ID = items[0].Trim();
                        string Name = items[1].Trim();
                        string Position = items[2].Trim();

                        if (Position == "President")
                        {
                           President.Add(ID,new PositionModel(ID, Name, 0));
                        }
                        else if(Position == "Vice President")
                        {
                            VicePresident.Add(ID, new PositionModel(ID, Name, 0));
                        }
                        else if(Position == "General Secretary")
                        {
                            GeneralSecretary.Add(ID, new PositionModel(ID, Name, 0));
                        }
                           
                    }
                }
                else
                    Console.WriteLine("File does not exists!");
                Reader.Close();
            }
            catch (Exception excp)
            {
                Console.WriteLine(excp.Message);
            }
        }

        private static string getCandidateName(string candidateID)
        {
            try
            {
                string path = @"../../../../CandidateList.txt", line = "";
                StreamReader Reader = System.IO.File.OpenText(path);
                if (System.IO.File.Exists(path))
                {
                    while ((line = Reader.ReadLine()) != null)
                    {
                        string[] items = line.Split(',');
                        string ID = items[0].Trim();
                        string Name = items[1].Trim();
                        string Position = items[2].Trim();

                        if (ID == candidateID)
                            return Name;
                    }
                }
                else
                    Console.WriteLine("File does not exists!");
                Reader.Close();
                return null;
            }
            catch (Exception excp)
            {
                Console.WriteLine(excp.Message);
                return null;
            }
        }

        private static void CountVotes()
        {
            try
            {
                string RetrievalPath = @"C:\Users\Alqama\Documents\visual studio 2017\Projects\metadata\Voters\";

                foreach (string file in Directory.EnumerateFiles(RetrievalPath, "*.xml"))
                {
                    XmlDocument doc = new XmlDocument();
                    doc.Load(file);

                    XmlElement root = doc.DocumentElement;
                    XmlNodeList nodes = root.SelectNodes("//Voters/Vote");

                    foreach (XmlNode node in nodes)
                    {
                        string CandidateID = node["CandidateID"].InnerText;
                        string Position = node["Position"].InnerText;

                        if (Position == "President")
                        {
                            PositionModel tempObj = President[CandidateID];
                            int vote = tempObj.votes;
                            vote = vote + 1;
                            tempObj.votes = vote;
                            President[CandidateID] = tempObj;
                        }
                        else if (Position == "Vice President")
                        {
                            PositionModel tempObj = VicePresident[CandidateID];
                            int vote = tempObj.votes;
                            vote = vote + 1;
                            tempObj.votes = vote;
                            VicePresident[CandidateID] = tempObj;
                        }
                        else if (Position == "General Secretary")
                        {
                            PositionModel tempObj = GeneralSecretary[CandidateID];
                            int vote = tempObj.votes;
                            vote = vote + 1;
                            tempObj.votes = vote;
                            GeneralSecretary[CandidateID] = tempObj;
                        }
                    }
                }
            }
            catch (Exception excp)
            {
                Console.WriteLine("Exception" + excp.Message);
            }
        }
        struct Position
        {
            public string name;
            public int votes;

            public Position(string name, int votes)
            {
                this.name = name;
                this.votes = votes;
            }
        };
        public ActionResult Index()
        {

           /* foreach (KeyValuePair<string, Dictionary<string, int>> entry in voters)
            {
                foreach (KeyValuePair<string, int> id in entry.Value)
                {
                    if(entry.Key == "President")
                    {
                        President.Add(new PositionModel(getCandidateName(id.Key), id.Value));
                    }
                    else if(entry.Key == "Vice President")
                    {
                        VicePresident.Add(new PositionModel(getCandidateName(id.Key), id.Value));
                    }
                    else if (entry.Key == "General Secretary")
                    {
                        GeneralSecretary.Add(new PositionModel(getCandidateName(id.Key), id.Value));
                    }
                }

            }*/

            ViewBag.President = President;
            ViewBag.VicePresident = VicePresident;
            ViewBag.GeneralSecretary = GeneralSecretary;

            return View(GeneralSecretary);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}